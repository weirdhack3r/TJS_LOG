#! /bin/bash
clear
printf '\033]2;INSTALLER\a'
echo -e "Press \e[1;33many key\e[0m to install the script..."
read -n 1
clear
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
if [[ "$DIR" != "/root/TJS_LOG" ]]
then
	echo -e "You didn't follow the github's simple install instructions.I will try to do it for you..."
	sleep 4
	if [[ -d /root/TJS_LOG ]]
	then
		rm -r /root/TJS_LOG
	fi
	mkdir /root/TJS_LOG
	cp -r "$DIR"/* /root/TJS_LOG
	chmod +x /root/TJS_LOG/install.sh
	gnome-terminal -e "bash /root/TJS_LOG/install.sh"
fi
echo -e "Installing TJS_LOG..."
sleep 1
echo -e "Fixing permissions"
sleep 2
chmod +x /root/TJS_LOG/TJS1
chmod +x /root/TJS_LOG/TJS2
chmod +x /root/TJS_LOG/TJS3
chmod +x /root/TJS_LOG/TJS31
chmod +x /root/TJS_LOG/TJS
chmod +x /root/TJS_LOG/TJS4
chmod +x /root/TJS_LOG/TJS41
chmod +x /root/TJS_LOG/TJS42
chmod +x /root/TJS_LOG/TJS43
chmod +x /root/TJS_LOG/ls/TJS31.sh
chmod +x /root/TJS_LOG/ls/TJS32.sh
chmod +x /root/TJS_LOG/ls/TJS33.sh
chmod +x /root/TJS_LOG/uninstall.sh
clear
echo -e "Copying script to /bin/TJS_LOG"
sleep 1
mkdir /bin/TJS_LOG
cd /root/TJS_LOG
cp /root/TJS_LOG/TJS /bin/TJS_LOG
cp /root/TJS_LOG/TJS1 /bin/TJS_LOG
cp /root/TJS_LOG/TJS2 /bin/TJS_LOG
cp /root/TJS_LOG/TJS3 /bin/TJS_LOG
cp /root/TJS_LOG/TJS31 /bin/TJS_LOG
cp /root/TJS_LOG/TJS4 /bin/TJS_LOG
cp /root/TJS_LOG/TJS41 /bin/TJS_LOG
cp /root/TJS_LOG/TJS42 /bin/TJS_LOG
cp /root/TJS_LOG/TJS43 /bin/TJS_LOG
clear
if [[ ! -d /root/handshakes ]]
then
	mkdir /root/handshakes
	echo -e "Made /root/handshake directory"
else
	echo -e "/root/handshakes directory detected.Good."
fi
if [[ ! -d /root/wordlists ]]
then
	mkdir /root/wordlists
	echo -e "Made /root/wordlists directory"
else
	echo -e "/root/wordlists directory detected.Good."
fi
while true
do
clear
echo -e "Are you \e[1;33mu\e[0mpdating or \e[1;33mi\e[0mnstalling the script?(\e[1;33mu\e[0m/\e[1;33mi\e[0m): "
echo -e "Only use 'i' for the first time."
read UORI
if [[ "$UORI" = "u" ]]
then 
	clear
	echo -e "Type 'changelog' to see what's new on this version"
	sleep 3
	break
elif [[ "$UORI" = "i" ]]
then
	clear
	BASHCHECK=$(cat ~/.bashrc | grep "bin/TJS_LOG")
	if [[ "$BASHCHECK" != "" ]]
	then
		echo -e "I SAID USE i ONLY ONE TIME..........."
		sleep 3
	fi
	echo -e "Adding TJS_LOG to PATH so you can access it from anywhere"
	sleep 1
	export PATH=/bin/TJS_LOG:$PATH
	sleep 1
	echo "export PATH=/bin/TJS_LOG:$PATH" >> ~/.bashrc
	sleep 1
	clear
	break
fi
done
clear
echo -e "DONE"
sleep 1
clear
echo -e "Open a NEW terminal and type 'TJS' to launch the script"
sleep  4
gnome-terminal -e TJS
exit
